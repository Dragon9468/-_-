<footer>
    <div class="footer">
        <div class="footer__title">
            <span>Thông tin chi tiết</span>
        </div>
    </div>
    
    <div class="footer__info">

        <div class="footer__info-content">
            <h3>Giới thiệu</h3>
            <p>Tiệm cơm Nori - Cơm nắm Onigiri tại Đà Nẵng</p>
            <p></p>
            <div class="footer__social">
                <a href="https://www.facebook.com/tiemcom.nori/#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.tiktok.com/@tiemcom.nori/#"><i class="fab fa-tiktok"></i></a>
                <a href="https://www.instagram.com/tiemcom.nori/#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>



        <div class="footer__info-content">
            <h3>Liên hệ</h3>
            <p>Địa chỉ: K42/24 Nguyễn Thành Hãn</p>
            <p>Sđt: 0965700799 - 0968120902</p>
        </div>

        <div class="footer__info-content">
            <h3>Fanpage</h3>
            <p>
                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ftiemcom.nori&tabs=timeline&width=300px&height=150px&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="150px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </p>
        </div>


    </div>

    <div class="footer__copyright">
        <center>2024 All rights reserved.</center>
    </div>
</footer>