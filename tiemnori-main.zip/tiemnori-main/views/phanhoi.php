<div class="body">
    <div class="body__mainTitle">
        <h2>✍ PHẢN HỒI CỦA BẠN VỀ CƠM NẮM CỦA NORI</h2>
    </div>

    <div>
        <div class="post">
            <div class="intro">
                <!-- Nội dung bài viết -->
                <h3></h3>
                <p style="font-family: Tahoma"></p>
                <form action="" method="GET" class="">
                    <input type="text" value="" placeholder="Phản hồi của bạn..." name="" class="" required>
                </form>
            </div>
        </div>
    </div>
</div>