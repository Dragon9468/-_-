<!-- Hiển thị chi tiết sản phẩm -->
<div class="body">
            <a class="buy_continute" href="index.php"><i class="fa fa-arrow-circle-left"></i> Trở lại mua hàng</a>
            <div class="post">
                <div class="intro">
                    <p>Coming soon</p>
                </div>                        
            </div>
    </div>