<div class="body">
    <div class="body__mainTitle">
        <h2>GIỚI THIỆU VỀ NORI</h2>
    </div>

    <div>
        <div class="post">
            <div class="intro">
                <!-- Nội dung bài viết -->
                <h3>✨Tiệm cơm Nori - Cơm nắm Onigiri tại Đà Nẵng✨</h3>
                <p style="font-family: Tahoma; padding: 10px 0;">🍙🍙 Cơm nắm thường được gọi là Onigiri, đây là một món ăn xuất phát từ Nhật Bản. Onigiri có ba phần bao gồm: Rong biển, cơm trắng và các vị bên trong cơm khác nhau. Onigiri ở tiệm cơm Nori các bạn có thể dùng cho bữa sáng - trưa - chiều - tối đều được.</p>
                <p></p>
                <p style="font-family: Tahoma">📌 𝐓𝐢𝐞̣̂𝐧 𝐥𝐨̛̣𝐢: Nori chuẩn bị sẵn, bạn chỉ việc “bỏ túi” và đem đi thôi</p>
                <p style="font-family: Tahoma">📌 𝐂𝐮𝐧𝐠 𝐜𝐚̂́𝐩 𝐝𝐢𝐧𝐡 𝐝𝐮̛𝐨̛̃𝐧𝐠: phù hợp để “măm măm” lấp đầy bụng đói sau khi vui chơi nè</p>
                <p style="font-family: Tahoma">📌 𝐃𝐞̂̃ 𝐝𝐚̀𝐧𝐠 𝐦𝐚𝐧𝐠 𝐭𝐡𝐞𝐨: Cơm nắm dễ đem theo và bảo quản vì có túi giấy bên </p>
                <p></p>
                <p style="font-family: Tahoma; padding: 10px 0; padding-top: 5px">Cơm nắm của Tiệm cơm Nori có 7 vị khác nhau:</p>
                
                <!-- Hình ảnh -->
                <img style="padding-top: 5px" src="img/menu.jpg" alt="">
            </div>
        </div>
    </div>
</div>

<div class="body">
    <div class="body__mainTitle">
        <h2>🍙 BẢO QUẢN CƠM NORI 🍙</h2>
    </div>

    <div>
        <div class="post">
            <div class="intro">
                
            
                <!-- Hình ảnh -->
                <img src="img/baoquan.jpg" alt="">
                
                <h3 style="padding-top: 10px">NHẬN ORDER TRƯỚC 1 NGÀY / TRONG NGÀY TRƯỚC 30 PHÚT</h3>
                <h3 style="padding: 10px 0px">THÔNG TIN LIÊN HỆ</h3>
                <p style="font-family: Tahoma"><strong>INSTAGRAM</strong>: @tiemcom.nori </p>
                <p style="font-family: Tahoma"><strong>FACEBOOK</strong>: Tiệm Cơm Nori - Onigiri Đà Nẵng </p>
                <p style="font-family: Tahoma; padding-top: 5px">🏠 42/24 Nguyễn Thành Hãn </p>
                <p style="font-family: Tahoma">☎️ 0965700799 - 0968120902 </p>
                <p style="font-family: Tahoma">⏰ 6:30 - 17:00 | T2 - CN </p>
            </div>
        </div>
    </div>
</div>