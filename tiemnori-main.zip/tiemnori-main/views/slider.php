<div class="post-slider">
    <i class="fa fa-chevron-left prev" aria-hidden="true"></i>
    <i class="fa fa-chevron-right next" aria-hidden="true"></i>

    <div class="post-wrapper">
        <div class="post">
            <img src="./img/BG-1.jpg" alt="">
        </div>
        <div class="post">
            <img lazy data-src="./img/BG-2.jpg" alt="">
        </div>
        <div class="post">
            <img lazy data-src="./img/BG-3.jpg" alt="">
        </div>
        <div class="post">
            <img lazy data-src="./img/BG-4.jpg" alt="">
        </div>
    </div>

</div>